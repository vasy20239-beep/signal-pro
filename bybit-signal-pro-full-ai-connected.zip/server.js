import express from "express";
import dotenv from "dotenv";
dotenv.config();
const app=express(); app.use(express.json({limit:"1mb"})); app.use(express.static("public"));
const BASE="https://api.bybit.com";
async function bybit(path,params={}) {
 const url=new URL(BASE+path); for(const [k,v] of Object.entries(params)) if(v!==undefined&&v!==null)url.searchParams.set(k,v);
 const r=await fetch(url); if(!r.ok) throw new Error(`Bybit HTTP ${r.status}`);
 const j=await r.json(); if(j.retCode!==0) throw new Error(j.retMsg||"Bybit API error"); return j.result;
}
app.get("/api/health",(_,res)=>res.json({ok:true,aiConfigured:!!process.env.OPENAI_API_KEY}));
app.get("/api/markets",async(req,res)=>{try{const r=await bybit("/v5/market/tickers",{category:"linear"});res.json(r.list.filter(x=>x.symbol.endsWith("USDT")).slice(0,200));}catch(e){res.status(502).json({error:e.message});}});
app.get("/api/market-data",async(req,res)=>{try{
 const symbol=String(req.query.symbol||"BTCUSDT").toUpperCase(), interval=String(req.query.interval||"15");
 const [k,f,oi,ob]=await Promise.all([
 bybit("/v5/market/kline",{category:"linear",symbol,interval,limit:100}),
 bybit("/v5/market/funding/history",{category:"linear",symbol,limit:1}),
 bybit("/v5/market/open-interest",{category:"linear",symbol,intervalTime:"15min",limit:1}),
 bybit("/v5/market/orderbook",{category:"linear",symbol,limit:25})
 ]);
 res.json({symbol,candles:k.list,funding:f.list?.[0]||null,openInterest:oi.list?.[0]||null,orderbook:ob});
 }catch(e){res.status(502).json({error:e.message});}});
app.post("/api/ai-analysis",async(req,res)=>{
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"OPENAI_API_KEY is not configured on server"});
 try{
 const {symbol,interval="15",candles=[],funding=null,openInterest=null,orderbook=null,indicators={}}=req.body||{};
 if(!symbol||!Array.isArray(candles)||candles.length<20)return res.status(400).json({error:"Provide symbol and at least 20 candles"});
 const snapshot={symbol,interval,candles:candles.slice(-80),funding,openInterest,orderbook,indicators};
 const prompt=`Analyze this crypto perpetual market snapshot. Return concise Ukrainian JSON with keys: bias (LONG|SHORT|NO TRADE), score (0-100 quality score, NOT probability), rationale (array), risks (array), entry (number or null), stopLoss (number or null), targets (array of numbers), invalidation (string). Use candle data and provided indicators/metrics; do not invent unavailable data. Prefer NO TRADE when signals conflict. Do not claim certainty or predict guaranteed profit. Snapshot: ${JSON.stringify(snapshot)}`;
 const response=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({model:process.env.OPENAI_MODEL||"gpt-5-mini",input:prompt})});
 if(!response.ok)throw new Error(`OpenAI API ${response.status}: ${await response.text()}`);
 const data=await response.json(); const text=data.output?.map(x=>x.content?.map(c=>c.text||"").join("")).join("\n")||"";
 res.json({analysis:text,model:process.env.OPENAI_MODEL||"gpt-5-mini"});
 }catch(e){res.status(500).json({error:e.message});}
});
const port=process.env.PORT||3000;app.listen(port,"0.0.0.0",()=>console.log("Bybit Signal PRO running on "+port));
