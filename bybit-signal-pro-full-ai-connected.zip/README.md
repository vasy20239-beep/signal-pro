# Bybit Signal PRO

Node/Express backend + static frontend. Uses public Bybit linear USDT market endpoints. AI analysis requires an OpenAI API key stored only in the server environment.

## Run
- `npm install`
- Copy `.env.example` to `.env` and set `OPENAI_API_KEY`
- `npm start`

## API
- `GET /api/health`
- `GET /api/markets`
- `GET /api/market-data?symbol=BTCUSDT&interval=15`
- `POST /api/ai-analysis` (snapshot JSON)

AI quality score is not a probability or guarantee. Public market data may be delayed/limited; no trading execution is included.
